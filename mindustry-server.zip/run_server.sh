#!/usr/bin/env bash
java -jar server.jar
